public class Draft {
    /* echo


    ***************************************

    pwd



    ****************************
    cd



     **********************************************

     ls

     try {
            var f = new File(current).listFiles();
            var a = new Vector <String>();
            for (int i = 0; i < f.length; i++) {
                File file = f[i];
                a.add(file.toString());
            }
            print(a);
            if (toFile > 0) {
                printToFile(a.toString());
            }
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }



     ****************************************

     ls-r

     try (Stream<Path> walk = Files.walk(Paths.get(currentDirectoryPath))) {
            // We want to find only regular files
            List<String> result = walk.filter(Files::isRegularFile)
                    .map(Path::toString).collect(Collectors.toList());

            result.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }

    *******************************************

    mkdir

     *******************************************
     rmdir


*****************************************************


      touch



***************************************************

                cp

                try {
            FR = new FileReader(f1);
        } catch (FileNotFoundException var11) {
            var11.printStackTrace();
        }

        FileWriter FW = null;

        try {
            FW = new FileWriter(f2);
        } catch (IOException var10) {
            var10.printStackTrace();
        }

        int f;
        try {
            while((f = FR.read()) != -1) {
                FW.write(f);
            }
        } catch (IOException | NullPointerException var12) {
            var12.printStackTrace();
            return;
        }

        try {
            FR.close();
            FW.close();
        } catch (IOException | NullPointerException var9) {
            var9.printStackTrace();
            return;
        }

        System.out.println("file copy done");



    ********************************************


    cp_r


    *************************************************

    rm




    ******************************************************
    cat



    ****************************************************

    exist


    */
}
